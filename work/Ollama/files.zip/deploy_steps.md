# Deploy Steps — SFCC Ollama Tooling (full update)

## 1. Create folder structure

```bash
mkdir -p ~/work/ollama/scripts
mkdir -p ~/work/ollama/repomix-configs
mkdir -p ~/work/AIWorkspace/work/ai-reports
```

## 2. Move loose files out of ~/work root

```bash
mv ~/work/Modelfile      ~/work/ollama/Modelfile
mv ~/work/scan_bugs.sh   ~/work/ollama/scripts/scan_bugs.sh
mv ~/work/gerar_doc.sh   ~/work/ollama/scripts/gerar_doc.sh
mv ~/work/dw_classes.txt ~/work/ollama/scripts/dw_classes.txt
```

## 3. Copy all new files into place

```bash
# Scripts
cp ~/Downloads/scan_bugs.sh           ~/work/ollama/scripts/scan_bugs.sh
cp ~/Downloads/gerar_doc.sh           ~/work/ollama/scripts/gerar_doc.sh
cp ~/Downloads/sfcc_controller_map.sh ~/work/ollama/scripts/sfcc_controller_map.sh

# Validation data
cp ~/Downloads/dw_classes.txt         ~/work/ollama/scripts/dw_classes.txt
cp ~/Downloads/dw_methods.txt         ~/work/ollama/scripts/dw_methods.txt

# Modelfiles
cp ~/Downloads/Modelfile              ~/work/ollama/Modelfile
cp ~/Downloads/Modelfile_docs         ~/work/ollama/Modelfile_docs

# Repomix config
cp ~/Downloads/baccarat.repomix.json  ~/work/ollama/repomix-configs/baccarat.json
```

## 4. Make scripts executable

```bash
chmod +x ~/work/ollama/scripts/*.sh
```

## 5. Build both Ollama models

```bash
# Bug scanner model (temperature 0.2)
ollama create sfcc-expert -f ~/work/ollama/Modelfile

# Documentation model (temperature 0.1, stricter)
ollama create sfcc-expert-docs -f ~/work/ollama/Modelfile_docs

# Verify both appear
ollama list
```

## 6. Add shell aliases to ~/.zshrc

```bash
cat >> ~/.zshrc << 'ALIASES'

# SFCC Ollama tooling
export OLLAMA_MAX_LOADED_MODELS=1
export OLLAMA_NUM_PARALLEL=1
alias sfcc-bugs="~/work/ollama/scripts/scan_bugs.sh"
alias sfcc-docs="~/work/ollama/scripts/gerar_doc.sh"
alias sfcc-map="~/work/ollama/scripts/sfcc_controller_map.sh"
ALIASES

source ~/.zshrc
```

## 7. Verify everything

```bash
sfcc-bugs          # should print usage error — means it's working
sfcc-docs          # same
sfcc-map           # same
ollama list        # should show sfcc-expert and sfcc-expert-docs
```

## 8. Run your first analysis

```bash
# Controller map first (no model, instant, zero risk)
sfcc-map baccarat

# Bug scan — full project
sfcc-bugs baccarat

# Bug scan — single cartridge (if full repo is too large)
sfcc-bugs baccarat cartridges/app_baccarat_core

# Documentation
sfcc-docs baccarat
```

Reports land at:
`~/work/AIWorkspace/work/ai-reports/<project>/`

---

## Final folder structure

```
~/work/
├── AIWorkspace/
│   └── work/                              ← Obsidian vault root
│       └── ai-reports/                    ← reports (visible in Obsidian)
│           ├── baccarat/
│           │   ├── ControllerMap_2026-06-07_2200.md
│           │   ├── Bugs_2026-06-07_2215.md
│           │   └── Docs_2026-06-07_2230.md
│           └── my-origines/
└── ollama/
    ├── Modelfile                          ← sfcc-expert (bugs, temperature 0.2)
    ├── Modelfile_docs                     ← sfcc-expert-docs (docs, temperature 0.1)
    ├── scripts/
    │   ├── scan_bugs.sh
    │   ├── gerar_doc.sh
    │   ├── sfcc_controller_map.sh
    │   ├── dw_classes.txt
    │   └── dw_methods.txt
    └── repomix-configs/
        ├── baccarat.json
        └── my-origines.json

~/projects/sfcc/                           ← untouched, scripts point here
├── baccarat/
└── my-origines/
```
