# Open WebUI Setup — Local SFCC AI Front-end

Open WebUI runs at `http://localhost:8081` and connects to your local Ollama instance.
It gives you a chat interface with file upload, conversation history, and model switching
— so instead of piping repomix output through bash you can drag files into a chat window.

> Port 8080 is reserved by your local Docker/PHP stack. Open WebUI runs on **8081**.

---

## Install

Requires Python 3.11+ (installed via Homebrew at `/opt/homebrew/bin/python3.11`).

```bash
/opt/homebrew/bin/python3.11 -m pip install open-webui
```

---

## Run

Always launch from `~/work/ollama` so the secret key and data files stay in the right place:

```bash
cd ~/work/ollama
open-webui serve --port 8081
```

Then open `http://localhost:8081` — create an admin account on first launch.

---

## Shell alias

Add to `~/.zshrc`:

```bash
alias webui="cd ~/work/ollama && open-webui serve --port 8081"
```

Then reload:

```bash
source ~/.zshrc
```

From now on just type `webui` to start it.

---

## Connect to your Ollama models

Open WebUI auto-discovers models from Ollama on `http://localhost:11434`.

On first launch go to **Settings → Connections** and verify the Ollama URL is set.
Your models (`sfcc-expert`, `sfcc-expert-docs`, `llama3.1:8b`) will appear in the model picker automatically.

---

## SFCC workflow in Open WebUI

**Bug analysis:**
1. Generate the repomix context file:
```bash
cd ~/projects/sfcc/baccarat
/Users/brunolopes/.volta/bin/npx repomix \
  --config ~/work/ollama/repomix-configs/baccarat.json \
  --output /tmp/baccarat-context.txt
```
2. Open `http://localhost:8081`
3. Select **sfcc-expert** in the model picker
4. Drag `/tmp/baccarat-context.txt` into the chat window
5. Ask: *"Analyse this SFRA code for bugs — focus on null pointer risks and Transaction.wrap misuse"*
6. Follow up in the same conversation: *"Show me the fix for the second issue"*

**Documentation:**
Same steps but select **sfcc-expert-docs** and ask for documentation.

---

## Files created by Open WebUI

All Open WebUI data lives in `~/work/ollama/`:

| File | Purpose |
|---|---|
| `.webui_secret_key` | Session signing key — do not share or commit |
| `data/` | Conversation history, user accounts, uploads |

---

## Stop the server

`Ctrl+C` in the terminal where it's running.

To check if it's already running on another terminal:

```bash
lsof -i :8081 | grep LISTEN
```
