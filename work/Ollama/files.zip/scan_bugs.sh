#!/bin/bash
# SFCC Bug Scanner — powered by Ollama (sfcc-expert)
# Usage: ./scan_bugs.sh <project-name> [cartridge-subfolder]
# Example: ./scan_bugs.sh baccarat
# Example: ./scan_bugs.sh baccarat cartridges/app_baccarat_core

set -e

# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPTS_DIR="$(cd "$(dirname "$0")" && pwd)"
DW_CLASSES="$SCRIPTS_DIR/dw_classes.txt"
DW_METHODS="$SCRIPTS_DIR/dw_methods.txt"
PROJECTS_ROOT="$HOME/projects/sfcc"
NPX="/Users/brunolopes/.volta/bin/npx"
VAULT_REPORTS="$HOME/work/AIWorkspace/work/ai-reports"
REPOMIX_CONFIGS="$SCRIPTS_DIR/../repomix-configs"

# ── Args ──────────────────────────────────────────────────────────────────────
if [ -z "$1" ]; then
    echo "❌ Error: Provide the project name."
    echo "   Usage: $(basename "$0") <project-name> [cartridge-subfolder]"
    echo "   Example: $(basename "$0") baccarat"
    echo "   Example: $(basename "$0") baccarat cartridges/app_baccarat_core"
    exit 1
fi

PROJECT="$1"
SUBFOLDER="${2:-}"
PROJ_DIR="$PROJECTS_ROOT/$PROJECT"
OUTPUT_TXT="$PROJ_DIR/.repomix-output.txt"
REPORT_DIR="$VAULT_REPORTS/$PROJECT"
REPORT_OUT="$REPORT_DIR/Bugs_$(date +%Y-%m-%d_%H%M).md"
REPOMIX_CONFIG="$REPOMIX_CONFIGS/$PROJECT.json"
SCAN_TARGET="${SUBFOLDER:-cartridges}"

# ── Guards ────────────────────────────────────────────────────────────────────
if [ ! -d "$PROJ_DIR" ]; then
    echo "❌ Error: Project folder not found: $PROJ_DIR"
    exit 1
fi

if [ ! -f "$DW_CLASSES" ]; then
    echo "❌ Error: dw_classes.txt not found at $DW_CLASSES"
    exit 1
fi

mkdir -p "$REPORT_DIR"

# ── Step 1: Pack ──────────────────────────────────────────────────────────────
echo "🔍 [1/4] Packaging SFRA code from: $PROJ_DIR/$SCAN_TARGET"
cd "$PROJ_DIR"

# Token estimate
ESTIMATED_WORDS=$(find "$SCAN_TARGET" \
    \( -name "*.js" -o -name "*.isml" -o -name "*.json" -o -name "*.xml" \) \
    -not -path "*/node_modules/*" \
    -not -path "*/dist/*" \
    -not -path "*/static/*" \
    2>/dev/null | xargs wc -w 2>/dev/null | tail -1 | awk '{print $1}')
ESTIMATED_WORDS="${ESTIMATED_WORDS:-0}"
echo "   Estimated size: ~${ESTIMATED_WORDS} words (~$((ESTIMATED_WORDS / 4)) tokens)"

if [ "$ESTIMATED_WORDS" -gt 180000 ]; then
    echo ""
    echo "   ❌ Codebase too large (~$((ESTIMATED_WORDS / 4))k tokens) — will exceed model context."
    echo "   Scope to a single cartridge: $(basename "$0") $PROJECT cartridges/app_${PROJECT}_core"
    echo ""
    read -r -p "   Continue anyway? [y/N] " CONFIRM
    [[ "$CONFIRM" =~ ^[Yy]$ ]] || exit 1
elif [ "$ESTIMATED_WORDS" -gt 90000 ]; then
    echo "   ⚠️  Large codebase — output may be truncated. Consider scoping to one cartridge."
fi

if [ -f "$REPOMIX_CONFIG" ]; then
    echo "   Using project repomix config: $REPOMIX_CONFIG"
    $NPX repomix --config "$REPOMIX_CONFIG" --output "$OUTPUT_TXT"
else
    echo "   No project config found, using defaults."
    $NPX repomix \
        --include "${SCAN_TARGET}/**/*.js,${SCAN_TARGET}/**/*.isml,${SCAN_TARGET}/**/*.json,${SCAN_TARGET}/**/*.xml" \
        --ignore "**/node_modules/**,**/dist/**,**/static/**,**/*.min.js,**/images/**,**/*.png,**/*.jpg,**/*.svg,**/fonts/**" \
        --output "$OUTPUT_TXT"
fi

# ── Step 2: Analyse ───────────────────────────────────────────────────────────
echo "🤖 [2/4] Sending to Ollama sfcc-expert for bug analysis..."
{
    echo "# SFCC Bug Report — $PROJECT"
    echo "**Generated:** $(date)"
    echo "**Project path:** $PROJ_DIR"
    [ -n "$SUBFOLDER" ] && echo "**Scope:** $SUBFOLDER"
    echo ""
    echo "> ⚠️ AI-generated report. All \`dw.*\` references marked as unverified"
    echo "> must be confirmed against the [SFCC API docs](https://documentation.b2c.commercecloud.salesforce.com/DOC2/index.jsp)."
    echo ""
    echo "---"
    echo ""
    cat "$OUTPUT_TXT" | ollama run sfcc-expert \
        "Analyse this SFRA codebase. Report only issues you can clearly identify from the code.

        1. NULL POINTER RISKS — objects returned from dw.* managers used without a prior null check
        2. dw.* API CALLS IN LOOPS — manager calls inside for/while without caching outside the loop
        3. TRANSACTION MISUSE — writes outside Transaction.wrap(), or Transaction.wrap() around reads
        4. MISSING SERVICE ERROR HANDLING — result.object accessed without checking result.ok first
        5. SERVER ROUTE MISUSE — res.render() inside server.append, or missing next() calls
        6. INPUT VALIDATION GAPS — req.querystring or req.form used without validation

        For each issue:
        - File path
        - Problematic code snippet (exact, from source)
        - Why it is a bug
        - Corrected code snippet

        Only report issues you can clearly see. If uncertain about a dw.* method, prefix with ⚠️ UNVERIFIED."
} > "$REPORT_OUT"

# ── Step 3: Validate dw.* classes ─────────────────────────────────────────────
echo "🔎 [3/4] Validating dw.* references..."

UNKNOWN_CLASSES=$(grep -oE 'dw\.[a-zA-Z]+\.[a-zA-Z]+' "$REPORT_OUT" 2>/dev/null | sort -u | while read cls; do
    grep -qF "$cls" "$DW_CLASSES" || echo "  - \`$cls\` (unknown class)"
done)

UNKNOWN_METHODS=""
if [ -f "$DW_METHODS" ]; then
    # Extract method calls: ClassName.methodName() patterns
    UNKNOWN_METHODS=$(grep -oE '[A-Z][a-zA-Z]+Mgr\.[a-zA-Z]+\b' "$REPORT_OUT" 2>/dev/null | sort -u | while read call; do
        grep -qF "$call" "$DW_METHODS" || echo "  - \`$call\` (unverified method)"
    done)
fi

UNKNOWN_ALL="${UNKNOWN_CLASSES}${UNKNOWN_METHODS}"

if [ -n "$UNKNOWN_ALL" ]; then
    {
        echo ""
        echo "---"
        echo ""
        echo "## ⚠️ Unverified dw.* References"
        echo ""
        echo "These classes or methods appear in the report but are not in the verified list."
        echo "Confirm against [SFCC API docs](https://documentation.b2c.commercecloud.salesforce.com/DOC2/index.jsp) before acting on any finding that references them."
        echo ""
        echo "$UNKNOWN_ALL"
    } >> "$REPORT_OUT"
    echo "   ⚠️  Unverified dw.* references flagged — see report footer"
else
    echo "   ✅ All dw.* references matched verified list"
fi

# ── Step 4: Cleanup ───────────────────────────────────────────────────────────
echo "🧹 [4/4] Cleaning up temp files..."
rm -f "$OUTPUT_TXT"

echo ""
echo "✅ Report saved to Obsidian vault:"
echo "   $REPORT_OUT"
