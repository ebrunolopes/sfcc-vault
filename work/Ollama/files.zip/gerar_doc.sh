#!/bin/bash
# SFCC Technical Documentation Generator — powered by Ollama (sfcc-expert-docs)
# Usage: ./gerar_doc.sh <project-name> [cartridge-subfolder]
# Example: ./gerar_doc.sh baccarat
# Example: ./gerar_doc.sh baccarat cartridges/app_baccarat_core

set -e

# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPTS_DIR="$(cd "$(dirname "$0")" && pwd)"
DW_CLASSES="$SCRIPTS_DIR/dw_classes.txt"
DW_METHODS="$SCRIPTS_DIR/dw_methods.txt"
PROJECTS_ROOT="$HOME/projects/sfcc"
NPX="/Users/brunolopes/.volta/bin/npx"
VAULT_REPORTS="$HOME/work/AIWorkspace/work/ai-reports"
REPOMIX_CONFIGS="$SCRIPTS_DIR/../repomix-configs"

# ── Args ──────────────────────────────────────────────────────────────────────
if [ -z "$1" ]; then
    echo "❌ Error: Provide the project name."
    echo "   Usage: $(basename "$0") <project-name> [cartridge-subfolder]"
    echo "   Example: $(basename "$0") baccarat"
    echo "   Example: $(basename "$0") my-origines cartridges/app_myo_core"
    exit 1
fi

PROJECT="$1"
SUBFOLDER="${2:-}"
PROJ_DIR="$PROJECTS_ROOT/$PROJECT"
OUTPUT_TXT="$PROJ_DIR/.repomix-output.txt"
REPORT_DIR="$VAULT_REPORTS/$PROJECT"
REPORT_OUT="$REPORT_DIR/Docs_$(date +%Y-%m-%d_%H%M).md"
REPOMIX_CONFIG="$REPOMIX_CONFIGS/$PROJECT.json"
SCAN_TARGET="${SUBFOLDER:-cartridges}"

# ── Guards ────────────────────────────────────────────────────────────────────
if [ ! -d "$PROJ_DIR" ]; then
    echo "❌ Error: Project folder not found: $PROJ_DIR"
    exit 1
fi

if [ ! -f "$DW_CLASSES" ]; then
    echo "❌ Error: dw_classes.txt not found at $DW_CLASSES"
    exit 1
fi

mkdir -p "$REPORT_DIR"

# ── Step 1: Pack ──────────────────────────────────────────────────────────────
echo "📦 [1/4] Packaging SFRA code from: $PROJ_DIR/$SCAN_TARGET"
cd "$PROJ_DIR"

# Token estimate
ESTIMATED_WORDS=$(find "$SCAN_TARGET" \
    \( -name "*.js" -o -name "*.isml" -o -name "*.json" -o -name "*.xml" \) \
    -not -path "*/node_modules/*" \
    -not -path "*/dist/*" \
    -not -path "*/static/*" \
    2>/dev/null | xargs wc -w 2>/dev/null | tail -1 | awk '{print $1}')
ESTIMATED_WORDS="${ESTIMATED_WORDS:-0}"
echo "   Estimated size: ~${ESTIMATED_WORDS} words (~$((ESTIMATED_WORDS / 4)) tokens)"

if [ "$ESTIMATED_WORDS" -gt 180000 ]; then
    echo ""
    echo "   ❌ Codebase too large (~$((ESTIMATED_WORDS / 4))k tokens) — will exceed model context."
    echo "   Scope to a single cartridge: $(basename "$0") $PROJECT cartridges/app_${PROJECT}_core"
    echo ""
    read -r -p "   Continue anyway? [y/N] " CONFIRM
    [[ "$CONFIRM" =~ ^[Yy]$ ]] || exit 1
elif [ "$ESTIMATED_WORDS" -gt 90000 ]; then
    echo "   ⚠️  Large codebase — documentation may be incomplete. Consider scoping to one cartridge."
fi

if [ -f "$REPOMIX_CONFIG" ]; then
    echo "   Using project repomix config: $REPOMIX_CONFIG"
    $NPX repomix --config "$REPOMIX_CONFIG" --output "$OUTPUT_TXT"
else
    echo "   No project config found, using defaults."
    $NPX repomix \
        --include "${SCAN_TARGET}/**/*.js,${SCAN_TARGET}/**/*.isml,${SCAN_TARGET}/**/*.json,${SCAN_TARGET}/**/*.xml" \
        --ignore "**/node_modules/**,**/dist/**,**/static/**,**/*.min.js,**/images/**,**/*.png,**/*.jpg,**/*.svg,**/fonts/**" \
        --output "$OUTPUT_TXT"
fi

# ── Step 2: Document ──────────────────────────────────────────────────────────
echo "📝 [2/4] Generating documentation with Ollama (sfcc-expert-docs)..."
{
    echo "# Technical Documentation — $PROJECT"
    echo "**Generated:** $(date)"
    [ -n "$SUBFOLDER" ] && echo "**Scope:** $SUBFOLDER"
    echo ""
    echo "> ⚠️ AI-generated document. All \`dw.*\` API references should be verified"
    echo "> against the [SFCC API docs](https://documentation.b2c.commercecloud.salesforce.com/DOC2/index.jsp)"
    echo "> before being treated as authoritative. See the Unverified References section at the end."
    echo ""
    echo "---"
    echo ""
    cat "$OUTPUT_TXT" | ollama run sfcc-expert-docs \
        "Generate structured technical documentation for this SFRA project.

        Only document what you can clearly see in the code.
        If you reference a dw.* class or method and are not certain it exists, prefix it with ⚠️ UNVERIFIED.
        Do not invent integrations, services, or behaviours not visible in the source.
        If a section has nothing to report, write: 'Not found in source.'

        ## 1. Cartridge Overview
        - List all custom cartridges with folder names
        - Suggested cartridge path order (most specific → least specific → base)
        - Purpose of each cartridge based on its contents

        ## 2. Controller Endpoints
        - Each controller and its routes (server.get/post/append/prepend/replace)
        - What each route does, what it renders or returns
        - Middleware or hooks observed

        ## 3. External Service Integrations
        - Services registered via LocalServiceRegistry (list service IDs)
        - Payment, shipping, or search integrations detected
        - Third-party API calls in scripts

        ## 4. Custom Objects & Metadata Extensions
        - Custom attribute groups in XML metadata
        - Custom object definitions
        - System object extensions

        ## 5. Hooks
        - Hook registrations in package.json files
        - Hook handler scripts and their purpose

        ## 6. Technical Debt & Risk Areas
        - Patterns likely to cause issues at scale
        - Missing error handling
        - Deprecated SFCC patterns observed
        - Code that should be refactored

        Use Markdown headings and inline code blocks. Be precise and concise."
} > "$REPORT_OUT"

# ── Step 3: Validate dw.* references ─────────────────────────────────────────
echo "🔎 [3/4] Validating dw.* references..."

UNKNOWN_CLASSES=$(grep -oE 'dw\.[a-zA-Z]+\.[a-zA-Z]+' "$REPORT_OUT" 2>/dev/null | sort -u | while read cls; do
    grep -qF "$cls" "$DW_CLASSES" || echo "  - \`$cls\` (unknown class)"
done)

UNKNOWN_METHODS=""
if [ -f "$DW_METHODS" ]; then
    UNKNOWN_METHODS=$(grep -oE '[A-Z][a-zA-Z]+Mgr\.[a-zA-Z]+\b' "$REPORT_OUT" 2>/dev/null | sort -u | while read call; do
        grep -qF "$call" "$DW_METHODS" || echo "  - \`$call\` (unverified method)"
    done)
fi

UNKNOWN_ALL="${UNKNOWN_CLASSES}${UNKNOWN_METHODS}"

if [ -n "$UNKNOWN_ALL" ]; then
    {
        echo ""
        echo "---"
        echo ""
        echo "## ⚠️ Unverified dw.* References"
        echo ""
        echo "These classes or methods appear in this document but are not in the verified list."
        echo "Confirm against [SFCC API docs](https://documentation.b2c.commercecloud.salesforce.com/DOC2/index.jsp) before including in official documentation."
        echo ""
        echo "$UNKNOWN_ALL"
    } >> "$REPORT_OUT"
    echo "   ⚠️  Unverified dw.* references flagged — see report footer"
else
    echo "   ✅ All dw.* references matched verified list"
fi

# ── Step 4: Cleanup ───────────────────────────────────────────────────────────
echo "🧹 [4/4] Cleaning up temp files..."
rm -f "$OUTPUT_TXT"

echo ""
echo "✅ Documentation saved to Obsidian vault:"
echo "   $REPORT_OUT"
